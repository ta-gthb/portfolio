from stegano import lsb

def encode_message(image_path, message, output_path):
    """
    Encodes a secret message into an image using LSB steganography.

    Parameters:
    - image_path (str): Path to the input image
    - message (str): Message to hide in the image
    - output_path (str): Path to save the image with the hidden message
    """
    secret = lsb.hide(image_path, message)
    secret.save(output_path)
    print(f"✅ Message encoded and saved to: {output_path}")

def decode_message(image_path):
    """
    Decodes a hidden message from an image.

    Parameters:
    - image_path (str): Path to the image with a hidden message
    """
    hidden_message = lsb.reveal(image_path)
    if hidden_message:
        print("🕵️‍♂️ Decoded message:", hidden_message)
    else:
        print("❌ No hidden message found.")

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Image Steganography using LSB")
    parser.add_argument("mode", choices=["encode", "decode"], help="Mode: encode or decode")
    parser.add_argument("--input", help="Input image path")
    parser.add_argument("--output", help="Output image path (for encode mode)")
    parser.add_argument("--message", help="Message to hide (for encode mode)")

    args = parser.parse_args()

    if args.mode == "encode":
        if args.input and args.output and args.message:
            encode_message(args.input, args.message, args.output)
        else:
            print("❗ Please provide --input, --output, and --message for encoding.")
    elif args.mode == "decode":
        if args.input:
            decode_message(args.input)
        else:
            print("❗ Please provide --input image path for decoding.")